/* See LICENSE file for license and copyright information */

#ifndef ZATHURA_VERSION_H
#define ZATHURA_VERSION_H

#define ZATHURA_VERSION_MAJOR 0
#define ZATHUAR_VERSION_MINOR 1
#define ZATHURA_VERSION_REV 1
#define ZATHURA_VERSION "0.1.1"
#define ZATHURA_API_VERSION 1

#endif
