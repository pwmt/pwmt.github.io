=========
zathurarc
=========

--------------------------
zathura configuration file
--------------------------

:Author: pwmt.org
:Date: VERSION
:Manual section: 5

SYNOPSIS
========

/etc/zathurarc, $XDG_CONFIG_HOME/zathura/zathurarc

DESCRIPTION
===========

The *zathurarc* file is a simple plain text file that can be populated with
various commands to change the behaviour and the look of zathura.

You can find a detailed description of *zathurarc* on the following website:
http://pwmt.org/projects/zathura/configuration

SEE ALSO
========

zathura(1)
