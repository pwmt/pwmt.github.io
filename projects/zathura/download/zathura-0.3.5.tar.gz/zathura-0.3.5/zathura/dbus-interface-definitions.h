/* See LICENSE file for license and copyright information */

#ifndef ZATHURA_DBUS_INTERFACE_DEFINITIONS
#define ZATHURA_DBUS_INTERFACE_DEFINITIONS

const char* DBUS_INTERFACE_XML;

#endif
