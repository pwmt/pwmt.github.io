/* SPDX-License-Identifier: Zlib */

#include "document.h"

#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <glib.h>
#include <gio/gio.h>
#include <math.h>
#include <xxhash.h>

#include <girara/datastructures.h>
#include <girara/log.h>
#include <girara/utils.h>

#include "zathura.h"
#include "page.h"
#include "plugin.h"
#include "content-type.h"
#include "internal.h"

G_DEFINE_AUTOPTR_CLEANUP_FUNC(XXH3_state_t, XXH3_freeState)

/**
 * Document
 */
struct zathura_document_s {
  void* data;                              /**< Custom data */
  char* file_path;                         /**< File path of the document */
  char* uri;                               /**< URI of the document */
  char* basename;                          /**< Basename of the document */
  uint8_t hash[DOCUMENT_DIGEST_SIZE];      /**< XXH3 hash of the document */
  bool hash_computed;                      /**< Whether the hash has been computed yet */
  const char* password;                    /**< Password of the document */
  unsigned int current_page_number;        /**< Current page number */
  unsigned int number_of_pages;            /**< Number of pages */
  double zoom;                             /**< Zoom value */
  unsigned int rotate;                     /**< Rotation */
  zathura_adjust_mode_t adjust_mode;       /**< Adjust mode (best-fit, width) */
  int page_offset;                         /**< Page offset */
  unsigned int view_width;                 /**< width of current viewport */
  unsigned int view_height;                /**< height of current viewport */
  double view_ppi;                         /**< PPI of the current viewport */
  zathura_device_factors_t device_factors; /**< x and y device scale factors (for e.g. HiDPI) */
  double position_x;                       /**< X adjustment */
  double position_y;                       /**< Y adjustment */

  /**
   * Document pages
   */
  zathura_page_t** pages;

  /**
   * Used plugin
   */
  const zathura_plugin_t* plugin;
};

static bool hash_file(uint8_t* dst, const char* path) {
  g_autoptr(GFile) f = g_file_new_for_path(path);
  if (f == NULL) {
    return false;
  }

  g_autoptr(GFileInputStream) stream = g_file_read(f, NULL, NULL);
  if (stream == NULL) {
    return false;
  }

  g_autoptr(XXH3_state_t) state = XXH3_createState();
  if (state == NULL) {
    return false;
  }
  XXH3_128bits_reset(state);

  uint8_t buf[MAX(BUFSIZ, 4096)];
  gssize read;
  while ((read = g_input_stream_read(G_INPUT_STREAM(stream), buf, sizeof(buf), NULL, NULL)) > 0) {
    XXH3_128bits_update(state, buf, read);
  }

  /* read is zero on a clean end of stream and negative on an error */
  if (read != 0) {
    return false;
  }

  XXH128_canonical_t canonical;
  XXH128_canonicalFromHash(&canonical, XXH3_128bits_digest(state));
  memcpy(dst, canonical.digest, DOCUMENT_DIGEST_SIZE);
  return true;
}

zathura_document_t* zathura_document_open(zathura_t* zathura, const char* path, const char* uri, const char* password,
                                          zathura_error_t* error) {
  if (zathura == NULL || path == NULL) {
    return NULL;
  }

  g_autoptr(GFile) file = g_file_new_for_path(path);
  if (file == NULL) {
    girara_error("Error while handling path '%s'.", path);
    zathura_check_set_error(error, ZATHURA_ERROR_UNKNOWN);
    return NULL;
  }

  g_autofree char* real_path = g_file_get_path(file);
  if (real_path == NULL) {
    girara_error("Error while handling path '%s'.", path);
    zathura_check_set_error(error, ZATHURA_ERROR_UNKNOWN);
    return NULL;
  }

  g_autofree char* content_type = zathura_content_type_guess(
      zathura->content_type_context, real_path, zathura_plugin_manager_get_content_types(zathura->plugins.manager));
  if (content_type == NULL) {
    girara_error("Could not determine file type.");
    zathura_check_set_error(error, ZATHURA_ERROR_UNKNOWN);
    return NULL;
  }

  const zathura_plugin_t* plugin = zathura_plugin_manager_get_plugin(zathura->plugins.manager, content_type);
  if (plugin == NULL) {
    girara_error("Unknown file type: '%s'", content_type);
    zathura_check_set_error(error, ZATHURA_ERROR_UNKNOWN);
    return NULL;
  }

  g_autoptr(zathura_document_t) document = g_try_malloc0(sizeof(zathura_document_t));
  if (document == NULL) {
    zathura_check_set_error(error, ZATHURA_ERROR_OUT_OF_MEMORY);
    return NULL;
  }

  document->file_path = g_steal_pointer(&real_path);
  document->uri       = g_strdup(uri);
  if (document->uri == NULL) {
    document->basename = g_file_get_basename(file);
  } else {
    g_autoptr(GFile) gf = g_file_new_for_uri(document->uri);
    document->basename  = g_file_get_basename(gf);
  }
  document->password         = password;
  document->zoom             = 1.0;
  document->plugin           = plugin;
  document->adjust_mode      = ZATHURA_ADJUST_NONE;
  document->view_height      = 0;
  document->view_width       = 0;
  document->view_ppi         = 0.0;
  document->device_factors.x = 1.0;
  document->device_factors.y = 1.0;
  document->position_x       = 0.0;
  document->position_y       = 0.0;

  /* open document */
  const zathura_plugin_functions_t* functions = zathura_plugin_get_functions(plugin);

  zathura_error_t int_error = functions->document_open(document);
  if (int_error != ZATHURA_ERROR_OK) {
    zathura_check_set_error(error, int_error);
    girara_error("could not open document\n");
    return NULL;
  }

  /* read all pages */
  document->pages = g_try_malloc0_n(document->number_of_pages, sizeof(zathura_page_t*));
  if (document->pages == NULL) {
    zathura_check_set_error(error, ZATHURA_ERROR_OUT_OF_MEMORY);
    return NULL;
  }

  for (unsigned int page_id = 0; page_id < document->number_of_pages; page_id++) {
    zathura_page_t* page = zathura_page_new(document, page_id, NULL);
    if (page == NULL) {
      zathura_check_set_error(error, ZATHURA_ERROR_OUT_OF_MEMORY);
      return NULL;
    }

    document->pages[page_id] = page;
  }

  return g_steal_pointer(&document);
}

zathura_error_t zathura_document_free(zathura_document_t* document) {
  if (document == NULL || document->plugin == NULL) {
    g_free(document);
    return ZATHURA_ERROR_INVALID_ARGUMENTS;
  }

  if (document->pages != NULL) {
    /* free pages */
    for (unsigned int page_id = 0; page_id < document->number_of_pages; page_id++) {
      zathura_page_free(document->pages[page_id]);
      document->pages[page_id] = NULL;
    }
    g_free(document->pages);
  }

  /* free document */
  const zathura_plugin_functions_t* functions = zathura_plugin_get_functions(document->plugin);

  zathura_error_t error = functions->document_free(document, document->data);

  g_free(document->file_path);
  g_free(document->uri);
  g_free(document->basename);
  g_free(document);

  return error;
}

const char* zathura_document_get_path(zathura_document_t* document) {
  if (document == NULL) {
    return NULL;
  }

  return document->file_path;
}

const uint8_t* zathura_document_get_hash(zathura_document_t* document) {
  if (document == NULL) {
    return NULL;
  }

  if (document->hash_computed == false) {
    document->hash_computed = true;
    if (hash_file(document->hash, document->file_path) == false) {
      girara_warning("Failed to hash file '%s'; fileinfo lookup may be unreliable.", document->file_path);
    }
  }

  return document->hash;
}

const char* zathura_document_get_uri(zathura_document_t* document) {
  if (document == NULL) {
    return NULL;
  }

  return document->uri;
}

const char* zathura_document_get_basename(zathura_document_t* document) {
  if (document == NULL) {
    return NULL;
  }

  return document->basename;
}

const char* zathura_document_get_password(zathura_document_t* document) {
  if (document == NULL) {
    return NULL;
  }

  return document->password;
}

zathura_page_t* zathura_document_get_page(zathura_document_t* document, unsigned int index) {
  if (document == NULL || document->pages == NULL) {
    return NULL;
  }

  g_return_val_if_fail(index < document->number_of_pages, NULL);
  return document->pages[index];
}

void* zathura_document_get_data(zathura_document_t* document) {
  if (document == NULL) {
    return NULL;
  }

  return document->data;
}

void zathura_document_set_data(zathura_document_t* document, void* data) {
  if (document == NULL) {
    return;
  }

  document->data = data;
}

unsigned int zathura_document_get_number_of_pages(zathura_document_t* document) {
  if (document == NULL) {
    return 0;
  }

  return document->number_of_pages;
}

void zathura_document_set_number_of_pages(zathura_document_t* document, unsigned int number_of_pages) {
  if (document == NULL) {
    return;
  }

  document->number_of_pages = number_of_pages;
}

unsigned int zathura_document_get_current_page_number(zathura_document_t* document) {
  if (document == NULL) {
    return 0;
  }

  return document->current_page_number;
}

void zathura_document_set_current_page_number(zathura_document_t* document, unsigned int current_page) {
  if (document == NULL) {
    return;
  }

  document->current_page_number = current_page;
}

double zathura_document_get_position_x(zathura_document_t* document) {
  if (document == NULL) {
    return 0;
  }

  return document->position_x;
}

double zathura_document_get_position_y(zathura_document_t* document) {
  if (document == NULL) {
    return 0;
  }

  return document->position_y;
}

void zathura_document_set_position_x(zathura_document_t* document, double position_x) {
  if (document == NULL) {
    return;
  }

  document->position_x = position_x;
}

void zathura_document_set_position_y(zathura_document_t* document, double position_y) {
  if (document == NULL) {
    return;
  }

  document->position_y = position_y;
}

double zathura_document_get_zoom(zathura_document_t* document) {
  if (document == NULL) {
    return 0;
  }

  return document->zoom;
}

void zathura_document_set_zoom(zathura_document_t* document, double zoom) {
  if (document == NULL) {
    return;
  }

  document->zoom = zoom;
}

double zathura_document_get_scale(zathura_document_t* document) {
  if (document == NULL) {
    return 0;
  }

  double ppi = document->view_ppi;
  if (ppi < DBL_EPSILON) {
    /* No PPI information -> use a typical value */
    ppi = 100;
  }

  /* scale = pixels per point, and there are 72 points in one inch */
  return document->zoom * ppi / 72.0;
}

unsigned int zathura_document_get_rotation(zathura_document_t* document) {
  if (document == NULL) {
    return 0;
  }

  return document->rotate;
}

void zathura_document_set_rotation(zathura_document_t* document, unsigned int rotation) {
  if (document == NULL) {
    return;
  }

  rotation = rotation % 360;
  if (rotation == 0 || rotation > 270) {
    document->rotate = 0;
  } else if (rotation <= 90) {
    document->rotate = 90;
  } else if (rotation <= 180) {
    document->rotate = 180;
  } else {
    document->rotate = 270;
  }
}

zathura_adjust_mode_t zathura_document_get_adjust_mode(zathura_document_t* document) {
  if (document == NULL) {
    return ZATHURA_ADJUST_NONE;
  }

  return document->adjust_mode;
}

void zathura_document_set_adjust_mode(zathura_document_t* document, zathura_adjust_mode_t mode) {
  if (document == NULL) {
    return;
  }

  document->adjust_mode = mode;
}

int zathura_document_get_page_offset(zathura_document_t* document) {
  if (document == NULL) {
    return 0;
  }

  return document->page_offset;
}

void zathura_document_set_page_offset(zathura_document_t* document, unsigned int page_offset) {
  if (document == NULL) {
    return;
  }

  document->page_offset = page_offset;
}

void zathura_document_set_viewport_width(zathura_document_t* document, unsigned int width) {
  if (document == NULL) {
    return;
  }
  document->view_width = width;
}

void zathura_document_set_viewport_height(zathura_document_t* document, unsigned int height) {
  if (document == NULL) {
    return;
  }
  document->view_height = height;
}

void zathura_document_set_viewport_ppi(zathura_document_t* document, double ppi) {
  if (document == NULL) {
    return;
  }
  document->view_ppi = ppi;
}

void zathura_document_get_viewport_size(zathura_document_t* document, unsigned int* height, unsigned int* width) {
  g_return_if_fail(document != NULL && height != NULL && width != NULL);
  *height = document->view_height;
  *width  = document->view_width;
}

double zathura_document_get_viewport_ppi(zathura_document_t* document) {
  if (document == NULL) {
    return 0.0;
  }
  return document->view_ppi;
}

void zathura_document_set_device_factors(zathura_document_t* document, double x_factor, double y_factor) {
  if (document == NULL) {
    return;
  }
  if (fabs(x_factor) < DBL_EPSILON || fabs(y_factor) < DBL_EPSILON) {
    girara_debug("Ignoring new device factors %0.2f and %0.2f: too small", x_factor, y_factor);
    return;
  }

  document->device_factors.x = x_factor;
  document->device_factors.y = y_factor;
}

zathura_device_factors_t zathura_document_get_device_factors(zathura_document_t* document) {
  if (document == NULL) {
    /* The function is guaranteed to not return zero values */
    return (zathura_device_factors_t){1.0, 1.0};
  }

  return document->device_factors;
}

zathura_error_t zathura_document_save_as(zathura_document_t* document, const char* path) {
  if (document == NULL || document->plugin == NULL || path == NULL) {
    return ZATHURA_ERROR_UNKNOWN;
  }

  const zathura_plugin_functions_t* functions = zathura_plugin_get_functions(document->plugin);
  if (functions->document_save_as == NULL) {
    return ZATHURA_ERROR_NOT_IMPLEMENTED;
  }

  return functions->document_save_as(document, document->data, path);
}

girara_tree_node_t* zathura_document_index_generate(zathura_document_t* document, zathura_error_t* error) {
  if (document == NULL || document->plugin == NULL) {
    zathura_check_set_error(error, ZATHURA_ERROR_INVALID_ARGUMENTS);
    return NULL;
  }

  const zathura_plugin_functions_t* functions = zathura_plugin_get_functions(document->plugin);
  if (functions->document_index_generate == NULL) {
    zathura_check_set_error(error, ZATHURA_ERROR_NOT_IMPLEMENTED);
    return NULL;
  }

  return functions->document_index_generate(document, document->data, error);
}

girara_list_t* zathura_document_attachments_get(zathura_document_t* document, zathura_error_t* error) {
  if (document == NULL || document->plugin == NULL) {
    zathura_check_set_error(error, ZATHURA_ERROR_INVALID_ARGUMENTS);
    return NULL;
  }

  const zathura_plugin_functions_t* functions = zathura_plugin_get_functions(document->plugin);
  if (functions->document_attachments_get == NULL) {
    zathura_check_set_error(error, ZATHURA_ERROR_NOT_IMPLEMENTED);
    return NULL;
  }

  return functions->document_attachments_get(document, document->data, error);
}

zathura_error_t zathura_document_attachment_save(zathura_document_t* document, const char* attachment,
                                                 const char* file) {
  if (document == NULL || document->plugin == NULL) {
    return ZATHURA_ERROR_INVALID_ARGUMENTS;
  }

  const zathura_plugin_functions_t* functions = zathura_plugin_get_functions(document->plugin);
  if (functions->document_attachment_save == NULL) {
    return ZATHURA_ERROR_NOT_IMPLEMENTED;
  }

  return functions->document_attachment_save(document, document->data, attachment, file);
}

girara_list_t* zathura_document_get_information(zathura_document_t* document, zathura_error_t* error) {
  if (document == NULL || document->plugin == NULL) {
    zathura_check_set_error(error, ZATHURA_ERROR_INVALID_ARGUMENTS);
    return NULL;
  }

  const zathura_plugin_functions_t* functions = zathura_plugin_get_functions(document->plugin);
  if (functions->document_get_information == NULL) {
    zathura_check_set_error(error, ZATHURA_ERROR_NOT_IMPLEMENTED);
    return NULL;
  }

  girara_list_t* result = functions->document_get_information(document, document->data, error);
  if (result != NULL) {
    girara_list_set_free_function(result, (girara_free_function_t)zathura_document_information_entry_free);
  }

  return result;
}

const zathura_plugin_t* zathura_document_get_plugin(zathura_document_t* document) {
  g_return_val_if_fail(document != NULL, NULL);

  return document->plugin;
}
