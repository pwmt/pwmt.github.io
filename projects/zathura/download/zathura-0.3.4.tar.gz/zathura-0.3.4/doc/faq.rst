FAQ
===

Set colors have no effect
-------------------------

If you want to overwrite a color you need to make sure that you either escape
the hash tag or put the new value between paranthesis.

::

  set color red
  set color \#000000
  set color "#000000"
