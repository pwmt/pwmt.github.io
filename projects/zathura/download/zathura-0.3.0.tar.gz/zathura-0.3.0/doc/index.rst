.. zathura documentation master file, created by
   sphinx-quickstart on Tue Apr  8 18:33:05 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to zathura's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :numbered:

   installation/index
   usage/index
   configuration/index
   api/index
   faq

.. toctree::
   :hidden:

   man/zathura.1
   man/zathurarc.5
