Manpage
=======

Synopsis
--------

.. include:: _synopsis.txt

Description
-----------

.. include:: _description.txt

Options
-------

.. include:: _options.txt

Mouse and key bindings
----------------------

.. include:: _bindings.txt

Commands
---------

.. include:: _commands.txt

Configuration
-------------

.. include:: _configuration.txt

Synctex support
---------------

.. include:: _synctex.txt

Known bugs
----------

.. include:: _bugs.txt

See Also
--------
`zathurarc(5)`
