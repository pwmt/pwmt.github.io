/* See LICENSE file for license and copyright information */

#ifndef ZATHURA_CONTENT_TYPE_H
#define ZATHURA_CONTENT_TYPE_H

const char* guess_content_type(const char* path);

#endif
