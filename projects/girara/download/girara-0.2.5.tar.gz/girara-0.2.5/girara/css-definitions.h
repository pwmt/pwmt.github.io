/* See LICENSE file for license and copyright information */

#ifndef GIRARA_CSS_DEFINITIONS_H
#define GIRARA_CSS_DEFINITIONS_H

#include "macros.h"

extern const char* CSS_TEMPLATE GIRARA_HIDDEN;

#endif
