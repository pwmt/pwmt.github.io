/* See LICENSE file for license and copyright information */

#ifndef GIRARA_CSS_DEFINITIONS_H
#define GIRARA_CSS_DEFINITIONS_H

#include "macros.h"

extern const char* CSS_TEMPLATE_PRE_3_20 GIRARA_HIDDEN;
extern const char* CSS_TEMPLATE_POST_3_20 GIRARA_HIDDEN;

#endif
