/* See LICENSE file for license and copyright information */

#ifndef UTILS_H
#define UTILS_H

#include "plugin.h"

void mupdf_page_extract_text(mupdf_document_t* mupdf_document,
    mupdf_page_t* mupdf_page);

#endif // UTILS_H
